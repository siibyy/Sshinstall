# Autoscript | Free To Use For All
## ⏩ AUTOSCRIPT WEBSOCKET MULTIPORT 443/80 DETAILS ⏪

[ SSH & XRAY SERVICES ] <br>
<br>
✅ OpenSSH : 22 <br>
✅ Dropbear : 109,143 <br>
✅ SSH SSL Websocket : 443 <br>
✅ Vmess WS TLS : 443 <br>
✅ Vless WS TLS : 443 <br>
✅ Trojan WS TLS : 443 <br>
✅ Shadowsocks WS TLS : 443 <br>
✅ Vmess gRPC : 443 <br>
✅ Vless gRPC : 443 <br>
✅ Trojan gRPC : 443 <br>
✅ Shadowsocks gRPC : 443 <br>
✅ SSH Websocket : 80,2082 <br>
✅ Vmess WS none TLS : 80 <br>
✅ Vless WS none TLS : 80 <br>
✅ Stunnel5 : 447,777 <br>
✅ Udp Custom : 1-65535 <br>

## Support OS
### Ubuntu 18.04, Ubuntu 20.04, Ubuntu 22.04
### Debian 9, Debian 10, Debian 11
