#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Checking VPS"

clear
figlet `SCRIPT ANGGUN PREMIUM
echo ""
read -n 1 -s -r -p "PRESS [ ENTER ] KELUAR MENU"
menu



