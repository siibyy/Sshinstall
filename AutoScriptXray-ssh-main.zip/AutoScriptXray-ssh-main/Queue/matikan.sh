#!/bin/bash
rm /var/log/*
rm /var/log/nginx/*
sleep 1
reboot