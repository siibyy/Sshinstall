#!/bin/bash
Queue-ip-trojan
Queue-ip-vless
Queue-ip-vmess
Queue-ip-ssh
Queue-quota-vless
Queue-quota-vmess
Queue-quota-trojan
